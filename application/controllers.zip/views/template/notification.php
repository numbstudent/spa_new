<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
         <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
						Enroll Step-2
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                          <?php
                          echo $notification."</br>";
                          echo $message;
                           ?>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
